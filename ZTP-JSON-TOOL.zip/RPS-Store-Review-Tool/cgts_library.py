import requests
import logging
import json
from dataclasses import dataclass
import uuid
import os


def set_base_url():
    global BASE_URL 
    BASE_URL = os.environ["CGTSBASEURL"]


@dataclass
class UpdateArtifact:
    name: str
    artifact_type_id: uuid
    metadata_version: int
    artifact_data: dict

    def to_json(self):
        data = {
            "name": self.name,
            "tags": {
                "plan": "High-Tier",
                "purpose": "internal-hpe",
            },
            "metadata": {
                "artifactTypeId": str(self.artifact_type_id),
                "owner": "cm-bastion@hpe.com",
                "revision": self.metadata_version,
                "createdBy": "cm-bastion@hpe.com",
                "updatedBy": "cm-bastion@hpe.com",
                "description": "ZTP SCID",
                "source": "SmartCID",
                "version": "1.0.0"
            },
            "artifactData": {
                "artifactDataType": "json",
                "data": json.dumps(self.artifact_data)
            }
        }
        return json.dumps(data)
    
@dataclass
class CreateArtifact:
    name: str
    artifact_type_id: uuid
    artifact_data: dict

    def to_json(self):
        data = {
            "name": self.name,
            "tags": {
                "plan": "High-Tier",
                "purpose": "internal-hpe",
            },
            "metadata": {
                "artifactTypeId": str(self.artifact_type_id),
                "owner": "cm-bastion@hpe.com",
                "createdBy": "cm-bastion@hpe.com",
                "updatedBy": "cm-bastion@hpe.com",
                "description": "ZTP SCID",
                "source": "SmartCID",
                "version": "1.0.0"
            },
            "artifactData": {
                "artifactDataType": "json",
                "data": json.dumps(self.artifact_data)
            }
        }
        return data

@dataclass
class UpdateStoreArtifact:
    name: str
    artifact_type_id: uuid
    metadata_version: int
    store_status: int
    artifact_data: dict

    def to_json(self):
        data = {
            "name": self.name,
            "tags": {
                "storeId": self.name,
                "storeStatus": self.store_status
            },
            "metadata": {
                "artifactTypeId": str(self.artifact_type_id),
                "revision": self.metadata_version,
                "owner": "cm-bastion@hpe.com",
                "updatedBy": "cm-bastion@hpe.com",
                "description": "ZTP SCID",
                "source": "SmartCID",
                "version": "1.0.0"
            },
            "artifactData": {
                "artifactDataType": "json",
                "data": json.dumps(self.artifact_data)
            }
        }
        return json.dumps(data)


def handle_response(response):
    logging.info(response.status_code)
    # logging.info(response.text)

    if response.status_code >= 200 and response.status_code < 300:
        return response.json()

    logging.info(response.text)
    if response.status_code == 401:
        logging.error("Unauthorized to access")
        raise ConnectionError("Unauthorized to access")

    if response.status_code == 404:
        return None

    logging.error("Exception from CGTS")
    raise ConnectionError("Exception from CGTS")

def get_artifact_types(authorization: str, filter: str):
    """
    :param authorization: Auth token
    :param filter: filter string
    :return:
    """
    try:
        headers = {
            "Authorization": authorization,
        }
        params = {
            "filter": filter
        }
        response = requests.get(f"{BASE_URL}/glgts/v1alpha1/artifact-types", params=params, headers=headers)
        return handle_response(response)
    except requests.exceptions.RequestException as e:
        logging.error(f"GET request failed: {e}")
        return None

def create_artifact(tenantid: str, deploymentid: str, authorization: str, instanceid=None, payload=None):
    """
    :param tenantid: Tenant ID
    :param deploymentid: Site Id
    :param instanceid: Instance ID (optional)
    :param authorization: Auth token
    :param payload: Artifact payload
    :return:
    """
    try:
        headers = {
            "Authorization": authorization,
            "X-Tenant-Id": tenantid,
            "X-Deployment-Id": deploymentid,
            # "X-Service-Instance-Id": instanceid
        }
        response = requests.post(f"{BASE_URL}/glgts/v1alpha1/artifacts", headers=headers, json=payload)
        return handle_response(response)
    except requests.exceptions.RequestException as e:
        logging.error(f"POST request failed: {e}")
        return None

def get_artifacts(deploymentid: str, tenantid: str, authorization: str, parent = False):
    """

    :param deploymentid: Site id
    :param tenantid: Tenant id
    :param filter: filter string
    :param authorization: Auth token
    :return:
    """
    try:
        headers = {
            "Authorization": authorization,
        }

        if parent:
            deploymentidtype = "parent-deployment-id"
        else:
            deploymentidtype = "deployment-id"

        response = requests.get(f"{BASE_URL}/glgts/v1alpha1/artifacts?{deploymentidtype}={deploymentid}&tenant-id={tenantid}", headers=headers)
        return handle_response(response)
    except requests.exceptions.RequestException as e:
        logging.error(f"GET request failed: {e}")
        return None

def get_artifact_with_filter(deploymentid: str, tenantid: str, filter: str, authorization: str, parent = False):
    """

    :param deploymentid: Site id
    :param tenantid: Tenant id
    :param filter: filter string
    :param authorization: Auth token
    :return:
    """
    try:
        headers = {
            "Authorization": authorization,
        }

        if parent:
            deploymentidtype = "parent-deployment-id"
        else:
            deploymentidtype = "deployment-id"

        if "name" in filter:
            filter_artifact = f"filter={filter}"
        elif "storeStatus" in filter:
            filter_artifact = f"filter-tags={filter}"
        else:
            filter_artifact = f"filter={filter}"

        response = requests.get(f"{BASE_URL}/glgts/v1alpha1/artifacts?{deploymentidtype}={deploymentid}&tenant-id={tenantid}&{filter_artifact}", headers=headers)
        return handle_response(response)
    except requests.exceptions.RequestException as e:
        logging.error(f"GET request failed: {e}")
        return None


def update_artifact_by_id(deploymentid: str, tenantid: str, instanceid: str, artifactid: str, authorization: str, payload= None):
    """
    :param deploymentid: Site Id
    :param tenantid: Tenant Id
    :param instanceid: instance id (optional)
    :param artifactid: Artifact Id
    :param authorization: Auth token
    :return:
    """
    try:

        headers = {
            "Authorization": authorization,
            "X-Tenant-Id": tenantid,
            "X-Deployment-Id": deploymentid,
            # "X-Service-Instance-Id": instanceid,
            "Content-Type": "application/json"
        }
        response = requests.put(f"{BASE_URL}/glgts/v1alpha1/artifacts/{artifactid}", headers=headers, data=payload)
        return handle_response(response)
    except requests.exceptions.RequestException as e:
        logging.error(f"GET request failed: {e}")
        return None
