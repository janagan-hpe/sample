import json
import logging
import os
import subprocess
import sys
import boto3
import pandas as pd
import yaml

from cgts_library import (UpdateStoreArtifact, get_artifact_types,
                          get_artifact_with_filter, get_artifacts,
                          set_base_url, update_artifact_by_id)

logging.basicConfig(
    filename='_log_store_review_.log',
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
destination_folder = 'Backup-cgts'
bootstrapping = {
    'integ': '/cgts/bootstrapping/integ/config',
    'prod': '/cgts/bootstrapping/prod/config'
}
dc_list = {
    "INTEG-DC" : "/integ/houston/config",
    "BGLR-DC" : "/integ/bglr/config",
    "SSC-DC": "/prod/ssc/config",
    "ATC-DC" : "/prod/atc/config"
}

store_status_list = ['reviewed', 'inReview', 'detected', 'readyForConfiguration', 'configurationSuccessful', 'configurationFailed']

ssm_client = boto3.client('ssm', region_name='us-west-2')
def get_parameter(parameter_name):
    try:
        response = ssm_client.get_parameter(
            Name=parameter_name,
            WithDecryption=True
        )
        parameter_value = response['Parameter']['Value']
        return parameter_value
    except ssm_client.exceptions.ParameterNotFound:
        print(f"Parameter '{parameter_name}' not found")
        sys.exit()
    except Exception as e:
        print(f"Error occurred: {e}")
        sys.exit()

def generate_token():
    global AUTHTOKEN
    AUTHTOKEN = ""
    try:
        AUTHTOKEN = subprocess.check_output([os.environ["SCM_CONFIG_TOKEN_PATH"], "-t", "root"], stderr=subprocess.STDOUT)
    except subprocess.CalledProcessError as err:
        print(f"Command failed with error: {err.output}")
        sys.exit()

def _create_bootstrapconfig_yaml(config_path):
    if "Integ" in config_path:
        bootstrap_config = json.loads(get_parameter(bootstrapping['integ']))
    elif "Prod" in config_path:
        bootstrap_config = json.loads(get_parameter(bootstrapping['prod']))

    with open(config_path, 'w') as file:
        yaml.dump(bootstrap_config, file)

def _update_store_artifact_by_id_cgts(artifact_name, artifact_id, artifact_type_id, store_deployment_id, instance_id, metadata_version, store_status, json_data):
    return update_artifact_by_id(
        deploymentid=store_deployment_id,
        tenantid=TENANTID,
        instanceid=instance_id,
        artifactid=artifact_id,
        authorization=AUTHTOKEN,
        payload=UpdateStoreArtifact(artifact_name, artifact_type_id, metadata_version, store_status, json_data).to_json()
    )

def _get_artifact_type_cgts(auth_token: str, artifact_type_name):
    filter_by_name = f"name eq '{artifact_type_name}'"
    response = get_artifact_types(auth_token, filter_by_name)
    if response:
        return response["items"][0]["id"]

def _get_artifacts_by_filter_cgts(artifact_name: str, artifact_type_id, _deployment_id):
    response = get_artifact_with_filter(
        deploymentid=_deployment_id,
        tenantid=TENANTID,
        filter=f"name eq '{artifact_name}'",
        authorization=AUTHTOKEN,
        parent=True)
    
    if response:
        for item in response["items"]:
            metadata = item.get("metadata", None)
            if  metadata and metadata["artifactTypeId"] == artifact_type_id:
                return item
    return None

def _list_store_artifact_in_dc():
    generate_token()
    print("----------------STORE ARTIFACTS--------------------")
    store_artifact_type_id = _get_artifact_type_cgts(AUTHTOKEN, STOREINVENTORY)
    repo_files_all = get_artifacts(DEPLOYMENTID, TENANTID, AUTHTOKEN, parent=True)
    if repo_files_all and store_artifact_type_id:
        store_artifacts = []
        for item in repo_files_all["items"]:
            metadata = item.get("metadata", None)
            if  metadata and metadata["artifactTypeId"] == store_artifact_type_id:
                store_artifacts.append([item['name'], item['tags']['storeStatus']])
    df = pd.DataFrame(store_artifacts, columns=['STOREID', 'STORE_STATUS'])
    print(df.to_string())
    print("----------------------------------------------------\n")

def _download_store_artifact_(_store_id):
    print(f"----------------DOWLOADING {_store_id} ARTIFACT--------------------")
    generate_token()
    store_artifact_type_id = _get_artifact_type_cgts(AUTHTOKEN, STOREINVENTORY)
    repo_file = _get_artifacts_by_filter_cgts(_store_id, store_artifact_type_id, DEPLOYMENTID)
    if repo_file and store_artifact_type_id:
        repo_file_content = json.loads(repo_file["artifactData"]["data"])
        if not os.path.exists(destination_folder):
            os.makedirs(destination_folder)
        with open(f"Backup-cgts/{_store_id}.json", "w") as download_file:
            json.dump(repo_file_content, download_file, indent=4)
    print(f"----------------DOWLOADED {_store_id} ARTIFACT--------------------\n")

def _upload_the_artifact():
    _store_id = input("Confirmation to proceed to upload, Enter the StoreID Eg: (STXXXX)/exit: ")
    if _store_id.lower() == "exit":
        print("Exiting the program!!")
        exit()
    store_file_path = os.path.join(destination_folder, _store_id+".json")
    if store_file_path:
        with open(store_file_path, 'r', encoding="utf-8") as json_file:
            json_data = json.load(json_file)
        
        generate_token()
        store_artifact_type_id = _get_artifact_type_cgts(AUTHTOKEN, STOREINVENTORY)
        repo_file = _get_artifacts_by_filter_cgts(_store_id, store_artifact_type_id, DEPLOYMENTID)
        if repo_file and store_artifact_type_id:
            print(f"----------------UPLOADING {_store_id} ARTIFACT--------------------")
            store_status = store_status_list[0]
            print(f"Setting {_store_id} ARTIFACT status to '{store_status_list[0]}' ")
            artifact_id = repo_file["id"]
            instance_id = repo_file["serviceInstanceId"]
            metadata_version = int(repo_file["metadata"]["revision"])
            store_deployment_id = repo_file['deploymentId']
            print(f"FYI Uploaded to edge_deployement_id: {store_deployment_id}")
            _ = _update_store_artifact_by_id_cgts(_store_id, artifact_id, store_artifact_type_id, store_deployment_id, instance_id, metadata_version, store_status, json_data)
            print(f"----------------UPLOADED {_store_id} ARTIFACT--------------------\n")

def setup_prerequisites(config_path):
    global FACTORYNODEJSON, STOREMAPPINGJSON, STORENETWORKJSON, DATACENTERJSON, FACTORYINVENTORY, STOREMAPPINGINVENTORY, STORENETWORKINVENTORY, DATACENTERINVENTORY, STOREINVENTORY
    global DEPLOYMENTID, TENANTID

    ssm_parameters_ = get_parameter(config_path)
    if ssm_parameters_:
        config = json.loads(ssm_parameters_)
        os.environ["SCM_ACCESS_KEY"] = config["SCM_AWS_ACCESS_KEY_ID"]
        os.environ["SCM_SECRET_KEY"] = config["SCM_AWS_SECRET_KEY_ID"]
        os.environ["SCM_REGION"] = config["SCM_AWS_REGION_NAME"]
        os.environ["SCM_CONFIG_PATH"] =  config["SCM_CONFIG_PATH"]
        os.environ["CGTSBASEURL"] = config["CGTSBASEURL"]
        os.environ["SCM_CONFIG_TOKEN_PATH"] = config["SCM_CONFIG_TOKEN_PATH"]

    _create_bootstrapconfig_yaml(config["SCM_CONFIG_PATH"])
    FACTORYNODEJSON = config["FACTORYNODEJSON"]
    STOREMAPPINGJSON = config["STOREMAPPINGJSON"]
    STORENETWORKJSON = config["STORENETWORKJSON"]
    DATACENTERJSON = config["DATACENTERJSON"]
    FACTORYINVENTORY = config["FACTORYINVENTORY"]
    STOREMAPPINGINVENTORY = config["STOREMAPPINGINVENTORY"]
    STORENETWORKINVENTORY = config["STORENETWORKINVENTORY"]
    DATACENTERINVENTORY = config["DATACENTERINVENTORY"]
    STOREINVENTORY = config["STOREINVENTORY"]
    DEPLOYMENTID = config["DEPLOYMENTID"]
    TENANTID = config["TENANTID"]
    set_base_url()

if __name__ == "__main__":
    print("----------------Environment----------------------")
    print("Type 'exit' for exiting the program anytime!!")
    while True:
        dc_keys = []
        for key, value in enumerate(dc_list, start=1):
            print(f"{key}. {value}")
            dc_keys.append(value)
        choice = input("Choose the environment number to proceed? (int)/exit: ")
        if choice.lower() == "exit":
            print("Exiting the program!!")
            exit()
        try:
            num = int(choice)
            if 1 <= num <= 4:
                params_path = dc_list[dc_keys[num-1]]
                setup_prerequisites(params_path)
                _list_store_artifact_in_dc()
                choice = input("Are you going to Upload or Download? Eg:(upload/download/exit)?: ")
                if choice.lower() == "exit":
                    print("Exiting the program!!")
                    exit()
                elif choice.lower() == "download":
                    store_id = input("Enter the StoreID to review? Eg:(STXXXX): ")
                    if store_id.lower() == "exit":
                        print("Exiting the program!!")
                        exit()
                    _download_store_artifact_(store_id)
                    review_ans = input(f"Is the {store_id} reviewed? (Case Sensitive Yes/No/exit): ")
                    if review_ans.lower() == "exit":
                        print("Exiting the program!!")
                        exit()
                    elif review_ans == "Yes":
                        _upload_the_artifact()
                    else:
                        pass
                elif choice.lower() == "upload":
                    _upload_the_artifact()
                else:
                    pass
            else:
                print("High integer given!!\n")
        except Exception as er:
            print(f"Error: {er}")