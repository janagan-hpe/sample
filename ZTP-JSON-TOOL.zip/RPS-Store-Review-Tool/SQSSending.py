import boto3
import json

sqs = boto3.client('sqs', region_name='us-west-2')

queues_list = {
    "integ": "houston-lab-integ-queue",
    "prod": "thd-prod-queue"
}

def send_message(_queue_name):
    try:
        response = sqs.get_queue_url(QueueName=_queue_name)
        queue_url = response['QueueUrl']
        store_id = input("Enter the StoreId in the format (case sensitive) Eg: STXXXX : ").strip()
        if store_id == "exit":
            print("Exiting the program!!")
            exit()
        elif "ST" in store_id:
            body = {
                "storeID": store_id
            }
            response = sqs.send_message(
                QueueUrl=queue_url,
                MessageBody=json.dumps(body)
            )
            print(f"Message sent: {response['MessageId']}\n")
        else:
            print("StoreID is not proper!!\n")
    except Exception as err:
        print(f"Error: {err}\n")

if __name__ == "__main__":
    print("----------------Environment----------------------")
    print("Type 'exit' for exiting the program anytime!!")
    while True:
        queues_keys = []
        for key, value in enumerate(queues_list, start=1):
            print(f"{key}. {value}")
            queues_keys.append(value)
        choice = input("Choose the environment number to proceed? (int): ")
        if choice.lower() == "exit":
            print("Exiting the program!!")
            exit()
        try:
            num = int(choice)
            if 1 <= num <= 2:
                queue_name = queues_list[queues_keys[num-1]]
                send_message(queue_name)
            else:
                print("High integer given!!\n")
        except Exception as err:
            print("Non integer given!!\n")